package es.florida.Tema2_ProgMulti;

import java.io.*;
import java.util.*;

public class Miniproyecto {
    public static void main(String[] args) {
        long inicioTotal = System.currentTimeMillis();

        List<String[]> neos = new ArrayList<>();

        // Leer fichero de entrada
        try (BufferedReader br = new BufferedReader(new FileReader("neos.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    neos.add(partes);
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer el fichero de NEOs.");
            return;
        }

        int totalNEOs = neos.size();
        int bloque = 4;
        int procesados = 0;

        while (procesados < totalNEOs) {
            List<Process> procesos = new ArrayList<>();

            for (int i = 0; i < bloque && procesados + i < totalNEOs; i++) {
                String[] datos = neos.get(procesados + i);
                String nombre = datos[0];
                String posicion = datos[1];
                String velocidad = datos[2];

                List<String> comando = new ArrayList<>();
                comando.add(System.getProperty("java.home") + File.separator + "bin" + File.separator + "java");
                comando.add("-cp");
                comando.add(System.getProperty("java.class.path"));
                comando.add("es.florida.Tema2_ProgMulti.CalculadorNEO");
                comando.add(nombre);
                comando.add(posicion);
                comando.add(velocidad);

                try {
                    ProcessBuilder pb = new ProcessBuilder(comando);
                    pb.inheritIO();
                    procesos.add(pb.start());
                } catch (IOException e) {
                    System.err.println("Error al lanzar proceso para " + nombre);
                }
            }

            // Esperar a que terminen los 4 procesos
            for (Process p : procesos) {
                try {
                    p.waitFor();
                } catch (InterruptedException e) {
                    System.err.println("Error al esperar proceso.");
                }
            }

            procesados += bloque;
        }

        long finTotal = System.currentTimeMillis();
        double tiempoTotalSegundos = (finTotal - inicioTotal) / 1000.0;
        double tiempoMedio = tiempoTotalSegundos / totalNEOs;

        System.out.printf("⏱️ Tiempo total de ejecución: %.2f segundos%n", tiempoTotalSegundos);
        System.out.printf("⏱️ Tiempo medio por NEO: %.2f segundos%n", tiempoMedio);
    }
}
