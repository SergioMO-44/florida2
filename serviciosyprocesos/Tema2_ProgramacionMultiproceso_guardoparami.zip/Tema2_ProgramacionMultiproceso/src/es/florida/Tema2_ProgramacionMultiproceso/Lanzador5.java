package es.florida.Tema2_ProgramacionMultiproceso;

import java.io.*;
import java.util.*;

public class Lanzador5 {
    public static void main(String[] args) {
        String clase = "es.florida.Tema2_ProgramacionMultiproceso.Sumador1";
        File salida = new File("salidaSumador1.txt");

        List<String> command = new ArrayList<>();
        command.add(System.getProperty("java.home") + File.separator + "bin" + File.separator + "java");
        command.add("-cp");
        command.add(System.getProperty("java.class.path"));
        command.add(clase);
        command.add("1");
        command.add("100");

        try {
            ProcessBuilder builder = new ProcessBuilder(command);
            builder.redirectOutput(salida);
            Process process = builder.start();
            process.waitFor();
            System.out.println("Salida guardada en " + salida.getName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

