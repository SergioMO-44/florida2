package es.florida.Tema2_ProgramacionMultiproceso;

import java.util.Scanner;

public class Tema2ejercicios1al7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("📘 Selector de ejercicios - Tema 2: Programación multiproceso");
        System.out.println("-------------------------------------------------------------");
        System.out.println("1. Ejecutar Sumador1");
        System.out.println("2. Ejecutar Lanzador1");
        System.out.println("3. Ejecutar Sumador2");
        System.out.println("4. Ejecutar Lanzador2");
        System.out.println("5. Ejecutar Lanzador3");
        System.out.println("6. Ejecutar Lanzador4");
        System.out.println("7. Ejecutar Lanzador5");
        System.out.print("Selecciona una opción (1–7): ");

        int opcion = sc.nextInt();
        String clase = "";

        switch (opcion) {
            case 1: clase = "Sumador1"; break;
            case 2: clase = "Lanzador1"; break;
            case 3: clase = "Sumador2"; break;
            case 4: clase = "Lanzador2"; break;
            case 5: clase = "Lanzador3"; break;
            case 6: clase = "Lanzador4"; break;
            case 7: clase = "Lanzador5"; break;
            default:
                System.out.println("❌ Opción no válida. Introduce un número entre 1 y 7.");
                sc.close();
                return;
        }

        try {
            ProcessBuilder pb = new ProcessBuilder("java", clase);
            pb.inheritIO(); // Redirige entrada/salida directamente a consola
            Process proceso = pb.start();
            proceso.waitFor();
        } catch (Exception e) {
            System.out.println("⚠️ Error al ejecutar la clase: " + clase);
            e.printStackTrace();
        }

        sc.close();
    }
}

