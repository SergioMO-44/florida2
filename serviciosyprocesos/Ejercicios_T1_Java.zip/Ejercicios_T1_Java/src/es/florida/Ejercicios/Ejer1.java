package es.florida.Ejercicios;

public class Ejer1 {

	public static void main(String[] args) {
		 int numero1 = 7;
	        int numero2 = 13;
	        int suma = numero1 + numero2;
	        System.out.println("La suma es: " + suma);
	}

}
